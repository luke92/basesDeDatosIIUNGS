<?php
phpinfo();
echo getenv('INFORMIXSERVER');
echo getenv('INFORMIXDIR');
echo getenv('REMOTE_ADDR');
?>
