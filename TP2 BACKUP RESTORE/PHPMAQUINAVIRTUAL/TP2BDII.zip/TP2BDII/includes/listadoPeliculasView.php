<div class="container"> 
<table class="table table-striped">
    <thead>
      <tr>
        <th>ID Pelicula</th>
        <th>Nombre</th>
      </tr>
    </thead>
    <tbody>
        
    </tbody>
  </table>
</div>